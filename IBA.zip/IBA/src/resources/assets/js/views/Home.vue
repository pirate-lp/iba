<template>
<div>
	<p>Welcome to ...</p>
	<p>Powered by Interactive Books' Atelier, a product of Lost Ideas Lab's Design & Development</p>
</div>
</template>

<script>

export default {
	data () {
		return {
		}
	},
	components: {
		
	},
	methods: {
	},
	mounted() {
	},
}
</script>

</style>
</style>
