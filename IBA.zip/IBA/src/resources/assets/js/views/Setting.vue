<template>
<div>
	<h2>Settings</h2>
	<p>Settings to be added afterward ...</p>
</div>
</template>

<script>

export default {
	data () {
		return {
		}
	},
	components: {
		
	},
	methods: {
	},
}
</script>

</style>
</style>
