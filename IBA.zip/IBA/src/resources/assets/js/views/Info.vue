<template>
	<div>
		<article>
			<h1>Interactive Book Atelier</h1>
			<h2>About</h2>
			<ul>
					<li>Web Version</li>
					<li>Backend: 0.1.1</li>
					<li>Frontend.Backend: 0.0.3</li>
					<li>Developed by Hossein @ Lost Ideas Lab</li>
					<li>More Information: Design & Development</li>
				</ul>
		</article>
	</div>
</template>

<script>
export default {
	name: 'info',
	data () {
		return {
			msg: 'Welcome to Your Vue.js App'
		}
	},
}
</script>

</style>
</style>
