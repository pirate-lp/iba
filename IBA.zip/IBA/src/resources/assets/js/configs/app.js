export default {
	host: 'http://lil.dev',
	client_id: '2',
	client_secret: '52HuTPCatxJNspuIwhKOTbIck5LTz4URd7dXyK2f',
}